#pragma once
#include "Required.h"
DWORD WINAPI mythread(LPVOID);
DWORD WINAPI hotkey_thread(LPVOID);
void GetAIdata(int data[4]);
void time_thread();
void ���ܻ�ȡ������();
void Getdatathread(int data[4]);
