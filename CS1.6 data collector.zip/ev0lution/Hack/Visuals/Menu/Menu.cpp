﻿#include "../../../Required.h"
#include "../../../images.h"

CMenu g_Menu;

#define MAX_TABS 5
#define TAB_WEIGHT 30
#define TAB_HEIGHT 30
#define BORDER_SIZE 4


typedef std::basic_string<TCHAR> tstring;

tstring VirtualKeyCodeToString(UCHAR virtualKey)
{
	UINT scanCode = MapVirtualKey(virtualKey, MAPVK_VK_TO_VSC);

	TCHAR szName[128];
	int result = 0;
	switch (virtualKey)
	{
	case VK_LEFT: case VK_UP: case VK_RIGHT: case VK_DOWN:
	case VK_PRIOR: case VK_NEXT:
	case VK_END: case VK_HOME:
	case VK_INSERT: case VK_DELETE:
	case VK_DIVIDE:
	case VK_NUMLOCK:
		scanCode |= KF_EXTENDED;
	default:
		result = GetKeyNameText(scanCode << 16, szName, 128);
	}
	if (result == 0)
		throw std::system_error(std::error_code(GetLastError(), std::system_category()),
			"WinAPI Error occured.");
	return szName;
}

void CMenu::Init()
{
	if (bInitialised)
		return;

	background.width = 492;//ШИРИНА МЕНЮ
	background.height = 500;//ВЫСОТА МЕНЮ


	bInitialised = true;
	bOpened = false;
	dwCheckboxBlockedTime = 0;
	dwSliderBlockedTime = 0;
	dwPaletteBlockedTime = 0;
	dwListBlockedTime = 0;

	//default menu position
	MenuX = 60;
	MenuY = 20;

	iCurrentTab = 3;//default tab
	cvar.menu_color_r = 255;
	cvar.menu_color_g = 0;
	cvar.menu_color_b = 0;

}

void CMenu::Run()
{
	Init();

	if (g_pGlobals.bSnapshot || g_pGlobals.bScreenshot)
		return;

	if (cvar.hide_from_obs && g_Local.status.connected && g_Local.iTeam == 0)
		return;

	static bool m_bMouseCapture = false;

	static bool m_bCursorState = false;

	static DWORD dwTemporaryBlockTimer = 0;

	int key = VK_INSERT;
	if (cvar.menu_key > 0 && cvar.menu_key < 255)
		key = cvar.menu_key;

	if (GetTickCount() - dwTemporaryBlockTimer > 200 && keys[key])
	{
		bOpened = !bOpened;
		dwTemporaryBlockTimer = GetTickCount();
	}

	if (!bOpened && m_bMouseCapture && g_pIRunGameEngine->IsInGame() && !g_pGameUI->IsGameUIActive())
	{
		g_pISurface->SetCursor(dc_none);
		g_pISurface->LockCursor();
		m_bMouseCapture = false;

		if (m_bCursorState)
		{
			g_pISurface->SurfaceSetCursorPos(g_Screen.iWidth / 2, g_Screen.iHeight / 2);
			m_bCursorState = false;
		}
	}

	if (!bOpened) //||
		//!g_pISurface->IsTextureIDValid(background.index)) ||
		//!g_pISurface->IsTextureIDValid(icon_headshot.index) || !g_pISurface->IsTextureIDValid(icon_aimbot.index) || !g_pISurface->IsTextureIDValid(icon_options.index) || !g_pISurface->IsTextureIDValid(icon_visuals.index)  || !g_pISurface->IsTextureIDValid(icon_members.index) ||
		//!g_pISurface->IsTextureIDValid(icon_headshot_not_selected.index) || !g_pISurface->IsTextureIDValid(icon_aimbot_not_selected.index) || !g_pISurface->IsTextureIDValid(icon_options_not_selected.index) || !g_pISurface->IsTextureIDValid(icon_visuals_not_selected.index) || !g_pISurface->IsTextureIDValid(icon_members_not_selected.index))
		return;

	if (g_pIRunGameEngine->IsInGame() && !g_pGameUI->IsGameUIActive())
	{
		g_pISurface->SetCursor(dc_arrow);
		g_pISurface->UnlockCursor();
		m_bMouseCapture = true;

		if (!m_bCursorState)
		{
			g_pISurface->SurfaceSetCursorPos(CursorX, CursorY);
			m_bCursorState = true;
		}
	}

	g_Engine.GetMousePosition(&CursorX, &CursorY);

	//g_Drawing.DrawTexture(background.index, MenuX, MenuY, background.width + MenuX, background.height + MenuY);//Draw background
	g_pISurface->DrawSetColor(255, 255, 255, 255);

	g_pISurface->DrawFilledRect(MenuX, MenuY, 269, 260);

	//if (DrawButton(MenuX + 2, MenuY + 2, "Legitbot"))
	//{
	//	iCurrentTab = 2;
	//}
	if (DrawButton(MenuX + 20, MenuY + 2, "Visuals"))
	{
		iCurrentTab = 3;
	}


	//Reset all
	bCursorInPalette = false;
	bCursorInList = false;
	iPaletteIndex = 0;
	iListIndex = 0;

	//SelectTab();
   // DrawMenuTabs();
	Tabs();
	Drag();
}

void CMenu::Tabs()
{
	static int m_iOldTab = iCurrentTab;

	if (m_iOldTab != iCurrentTab)
	{
		for (unsigned int i = 0; i < LIMIT_LISTBOX; i++)
			bListBoxOpened[i] = false;

		for (unsigned int i = 0; i < LIMIT_PALETTE; i++)
			bPaletteOpened[i] = false;

		m_iOldTab = iCurrentTab;
	}

	static unsigned int indent_x = 10;
	static unsigned int indent_y = 14;

	

	if (iCurrentTab == 3)//Visuals
	{
		int x = MenuX + 10;
		int y = MenuY + 30;
		int box_indent_x = 10;
		int box_indent_y = 15;

		int save[256];

		int line_y = 15;

		{
			DrawBox(x, y, 190, 203);

			g_pISurface->DrawSetColor(255, 255, 255, 255);
			//g_pISurface->DrawFilledRect(x + 14, y - 1, x + 50, y + 2);
			g_Drawing.DrawString(MENU, x + 16, y, 255, 0, 0, 255, FONT_LEFT, "Boxes");
			cvar.esp = 1;
			Checkbox(x + box_indent_x, y + line_y, cvar.esp, "Enabled");//自瞄
			line_y += 50;

			//Checkbox(x + box_indent_x, y + line_y, cvar.esp_teammates, "Teammates");
			//static char *typebox[] = { "0", "0", "Corner" };
			cvar.esp_box = 3;

			cvar.esp_behind = 1;
			Checkbox(x + box_indent_x, y + line_y, cvar.esp_behind, "Behind wall");
			line_y += 20;
		}



		{//draw no bug
			x = MenuX + 100;
			y = MenuY + 60;

			Palette(x + 120, save[5], cvar.esp_box_ct_invis_r, cvar.esp_box_ct_invis_g, cvar.esp_box_ct_invis_b);
			Palette(x + 100, save[5], cvar.esp_box_t_invis_r, cvar.esp_box_t_invis_g, cvar.esp_box_t_invis_b);

			Palette(x + 120, save[0], cvar.esp_box_ct_vis_r, cvar.esp_box_ct_vis_g, cvar.esp_box_ct_vis_b);
			Palette(x + 100, save[0], cvar.esp_box_t_vis_r, cvar.esp_box_t_vis_g, cvar.esp_box_t_vis_b);

			Palette(x + 120, save[2], cvar.glow_players_ct_r, cvar.glow_players_ct_g, cvar.glow_players_ct_b);
			Palette(x + 100, save[2], cvar.glow_players_t_r, cvar.glow_players_t_g, cvar.glow_players_t_b);


		/*	Palette(x + 120, save[1], cvar.esp_line_of_sight_r, cvar.esp_line_of_sight_g, cvar.esp_line_of_sight_b);*/


			Palette(x + 120, save[8], cvar.esp_bomb_r, cvar.esp_bomb_g, cvar.esp_bomb_b);
		}
	}

	
}

bool CMenu::DrawButton(int x, int y, char *text)
{
	unsigned int w = 160;
	unsigned int h = 18;

	g_pISurface->DrawSetColor(255, 0, 0, 255); // shadow
	g_pISurface->DrawOutlinedRect(x - 1, y - 1, x + w + 1, y + h + 1);

	g_pISurface->DrawSetColor(5, 5, 20, 255);
	g_pISurface->DrawOutlinedRect(x - 2, y - 2, x + w + 2, y + h + 2);

	bool clicked = false;

	static DWORD dwTemporaryBlockTimer = 0;

	if (GetTickCount() - dwPaletteBlockedTime > 200 && GetTickCount() - dwListBlockedTime > 200 && !bCursorInPalette && !bCursorInList && keys[VK_LBUTTON] && !IsDragging && CursorX >= x && CursorX <= x + w && CursorY >= y && CursorY <= y + h)
	{
		if (GetTickCount() - dwTemporaryBlockTimer > 200)
		{
			clicked = true;
			dwTemporaryBlockTimer = GetTickCount();
		}
	}

	if (clicked || CursorX >= x && CursorX <= x + w && CursorY >= y && CursorY <= y + h)
	{
		g_pISurface->DrawSetColor(255, 0, 0, 255); // цвет когда навели
		g_pISurface->DrawFilledRect(x, y, x + w, y + h);
	}
	else
	{
		g_pISurface->DrawSetColor(5, 5, 20, 255); // цвет
		g_pISurface->DrawFilledRect(x, y, x + w, y + h);
	}

	if (text)
		g_Drawing.DrawString(MENU, x + w / 2, y + (h / 2), 255, 255, 255, 255, FONT_CENTER, text);

	return clicked;
}

void CMenu::Palette(int x, int y, float &r, float &g, float &b)
{
	unsigned int w = 16;
	unsigned int h = 8;

	static DWORD dwTemporaryBlockTimer = 0;
	//Close others and open this
	if (GetTickCount() - dwListBlockedTime > 200 && GetTickCount() - dwPaletteBlockedTime > 200 && !bCursorInList && keys[VK_LBUTTON] && !IsDragging && CursorX >= x && CursorX <= x + w && CursorY >= y && CursorY <= y + h)
	{
		if (GetTickCount() - dwTemporaryBlockTimer > 200)
		{
			bPaletteOpened[iPaletteIndex] = !bPaletteOpened[iPaletteIndex];

			dwTemporaryBlockTimer = GetTickCount();

			for (unsigned int i = 0; i < LIMIT_PALETTE; i++)
			{
				if (i == iPaletteIndex) continue;

				if (bPaletteOpened[i])
					bPaletteOpened[i] = false;
			}
		}
	}

	g_pISurface->DrawSetColor(r, g, b, 255);
	g_pISurface->DrawFilledRect(x, y, x + w, y + h);

	//	g_pISurface->DrawSetColor(255, 0, 0, 255);
	//	g_pISurface->DrawOutlinedRect(x - 1, y - 1, x + w + 1, y + h + 1);

		//shadow
	g_pISurface->DrawSetColor(0, 0, 0, 255);
	g_pISurface->DrawOutlinedRect(x - 1, y - 1, x + w + 1, y + h + 1);

	static unsigned int panel_w = 230;
	static unsigned int panel_h = 54;
	static unsigned int indent = 8;
	static unsigned int border = 4;

	if (bPaletteOpened[iPaletteIndex])
	{
		g_pISurface->DrawSetColor(5, 5, 20, 255); //(120,168,93,255);
		g_pISurface->DrawFilledRect(x + w + indent - border, y - indent, x + w + panel_w + indent + border, y + panel_h + indent);

		g_pISurface->DrawSetColor(255, 255, 255, 255);
		g_pISurface->DrawOutlinedRect(x + w + indent - border - 1, y - indent - 1, x + w + panel_w + indent + border + 1, y + panel_h + indent + 1);

		//shadow
		//g_pISurface->DrawSetColor(0, 0, 0, 255);
		//g_pISurface->DrawOutlinedRect(x + w + indent - border - 2, y - indent - 2, x + w + panel_w + indent + border + 2, y + panel_h + indent + 2);

		SliderInPallete(x + w + indent, y, 0, 255, r, "", true);
		SliderInPallete(x + w + indent, y + 20, 0, 255, g, "", true);
		SliderInPallete(x + w + indent, y + 40, 0, 255, b, "", true);
	}

	if (bPaletteOpened[iPaletteIndex] && !IsDragging && CursorX >= x + w + indent - border && CursorX <= x + w + panel_w + indent + border && CursorY >= y - indent && CursorY <= y + panel_h + indent)
	{
		bCursorInPalette = true;
		dwCheckboxBlockedTime = GetTickCount();
		dwPaletteBlockedTime = GetTickCount();
		dwSliderBlockedTime = GetTickCount();
	}

	iPaletteIndex++;
}

void CMenu::ListBox(int index, int x, int y, char *name, float &value, char **text, int size, bool default)
{
	unsigned int w = 200;
	unsigned int h = 18;

	if (name)
		g_Drawing.DrawString(MENU, x + 1, y - 10, 0, 0, 0, 255, FONT_LEFT, name);

	static DWORD dwTemporaryBlockTimer = 0;
	//Close others and open this
	if (!bListBoxOpened[index] && GetTickCount() - dwPaletteBlockedTime > 200 && GetTickCount() - dwListBlockedTime > 200 && !bCursorInPalette && keys[VK_LBUTTON] && !IsDragging && CursorX >= x && CursorX <= x + w && CursorY >= y && CursorY <= y + h)
	{
		if (GetTickCount() - dwTemporaryBlockTimer > 200)
		{
			bListBoxOpened[index] = !bListBoxOpened[index];

			dwTemporaryBlockTimer = GetTickCount();

			for (unsigned int i = 0; i < LIMIT_LISTBOX; i++)
			{
				if (i == index) continue;

				if (bListBoxOpened[i])
				{
					bListBoxOpened[i] = false;
				}
			}
		}
	}

	bool effect_cursor = false;
	int effect_cursor_x0, effect_cursor_y0, effect_cursor_x1, effect_cursor_y1;
	int tmp = h;

	if (!bListBoxOpened[index])
	{
		g_pISurface->DrawSetColor(0, 0, 20, 255);//(120,168,93,255);
		g_pISurface->DrawFilledRect(x, y, x + w, y + tmp);

		g_pISurface->DrawSetColor(255, 0, 0, 255);
		g_pISurface->DrawOutlinedRect(x - 1, y - 1, x + w + 1, y + tmp + 1);

		//shadow
		g_pISurface->DrawSetColor(0, 0, 0, 255);
		g_pISurface->DrawOutlinedRect(x - 2, y - 2, x + w + 2, y + tmp + 2);

		bool m_bDrawDefault = true;

		for (unsigned int i = 0; i < size; i++)
		{
			if (text[i] && value == i + 1)
			{
				m_bDrawDefault = false;
				g_Drawing.DrawString(MENU, x + 4, y + (h / 2), 255, 255, 255, 255, FONT_LEFT, text[i]);
			}
		}

		if (m_bDrawDefault && default)
			g_Drawing.DrawString(MENU, x + 4, y + (h / 2), 255, 255, 255, 255, FONT_LEFT, "None");
	}
	else
	{
		for (unsigned int i = 0; i < size; i++)
		{
			if (text[i])
			{
				if (CursorX >= x && CursorX <= x + w && CursorY >= y + tmp - h && CursorY <= y + tmp)
				{
					effect_cursor_x0 = x;
					effect_cursor_x1 = x + w;
					effect_cursor_y0 = y + tmp - h;
					effect_cursor_y1 = y + tmp;
					effect_cursor = true;
				}

				if (GetTickCount() - dwTemporaryBlockTimer > 200 && keys[VK_LBUTTON] && !IsDragging && CursorX >= x && CursorX <= x + w && CursorY >= y + tmp - h && CursorY <= y + tmp)
				{
					value = i + 1;
					bListBoxOpened[index] = false;
					dwTemporaryBlockTimer = GetTickCount();
				}

				tmp += h;
			}
		}

		if (default)
		{
			if (GetTickCount() - dwTemporaryBlockTimer > 200 && keys[VK_LBUTTON] && !IsDragging && CursorX >= x && CursorX <= x + w && CursorY >= y && CursorY <= y + tmp)
			{
				value = 0;
				bListBoxOpened[index] = false;
				dwTemporaryBlockTimer = GetTickCount();
			}
		}
		else
			tmp -= h;

		g_pISurface->DrawSetColor(0, 0, 20, 255);//(120,168,93,255);
		g_pISurface->DrawFilledRect(x, y, x + w, y + tmp);

		g_pISurface->DrawSetColor(0, 0, 0, 255);
		g_pISurface->DrawOutlinedRect(x - 1, y - 1, x + w + 1, y + tmp + 1);

		//shadow
		g_pISurface->DrawSetColor(0, 0, 0, 255);
		g_pISurface->DrawOutlinedRect(x - 2, y - 2, x + w + 2, y + tmp + 2);
	}

	if (effect_cursor)
	{
		g_pISurface->DrawSetColor(255, 0, 0, 255);
		g_pISurface->DrawFilledRect(effect_cursor_x0, effect_cursor_y0, effect_cursor_x1, effect_cursor_y1);
	}

	if (bListBoxOpened[index])
	{
		tmp = h;

		for (unsigned int i = 0; i < size; i++)
		{
			if (text[i])
			{
				g_Drawing.DrawString(MENU, x + 4, y + tmp - (h / 2), 255, 255, 255, 255, FONT_LEFT, text[i]);
				tmp += h;
			}
		}

		if (default)
			g_Drawing.DrawString(MENU, x + 4, y + tmp - (h / 2), 220, 220, 220, 255, FONT_LEFT, "None");
		else
			tmp -= h;
	}

	if (bListBoxOpened[index] && !IsDragging && CursorX >= x && CursorX <= x + w && CursorY >= y && CursorY <= y + tmp)
	{
		bCursorInList = true;
		dwCheckboxBlockedTime = GetTickCount();
		dwListBlockedTime = GetTickCount();
		dwSliderBlockedTime = GetTickCount();
	}
}

void CMenu::SliderInPallete(int x, int y, float min, float max, float &value, char *text, bool ThisINT, char *amout, bool extra)
{
	unsigned int w = 230;
	unsigned int h = 12;

	g_pISurface->DrawSetColor(5, 5, 20, 255);//r(120,168,93,255);
	g_pISurface->DrawFilledRect(x, y, x + w, y + h);

	g_pISurface->DrawSetColor(255, 0, 0, 255);
	g_pISurface->DrawOutlinedRect(x - 1, y - 1, x + w + 1, y + h + 1);

	//shadow
	g_pISurface->DrawSetColor(5, 5, 20, 255);
	g_pISurface->DrawOutlinedRect(x - 2, y - 2, x + w + 2, y + h + 2);

	if (text)
		g_Drawing.DrawString(MENU, x + 1, y - 10, 255, 255, 255, 255, FONT_LEFT, text);

	if (ThisINT)
		value = (int)value;

	if (value < min)
		value = min;
	else if (value > max)
		value = max;

	float one = (w / max);

	int fill = one * value;

	if (value < 0)
		fill *= -1;

	g_pISurface->DrawSetColor(255, 0, 0, 255);
	g_pISurface->DrawFilledRect(x, y, x + fill, y + h);

	if (!amout)
		amout = "";

	if (!ThisINT)
	{
		if (!extra)
			g_Drawing.DrawString(MENU, x + (w / 2), y + (h / 2), 255, 255, 255, 255, FONT_CENTER, "%.2f%s", value, amout);
		else
			g_Drawing.DrawStringACP(MENU, x + (w / 2), y + (h / 2), 255, 255, 255, 255, FONT_CENTER, "%.2f%s", value, amout);
	}
	else
	{
		if (!extra)
			g_Drawing.DrawString(MENU, x + (w / 2), y + (h / 2), 255, 255, 255, 255, FONT_CENTER, "%.f%s", value, amout);
		else
			g_Drawing.DrawString(MENU, x + (w / 2), y + (h / 2), 255, 255, 255, 255, FONT_CENTER, "%.f%s", value, amout);
	}

	if (GetTickCount() - dwListBlockedTime > 200 && !bCursorInPalette && !bCursorInList && !IsDragging && CursorX >= x && CursorX <= x + w && CursorY >= y && CursorY <= y + h)
	{
		if (keys[VK_LBUTTON]) {
			value = (CursorX - x) / one;

			if (value < min)
				value = min;
			else if (value > max)
				value = max;
		}
		else if (keys[VK_RBUTTON] && min < 0) {
			value = (CursorX - x) / one;
			value *= -1;

			if (value < min)
				value = min;
			else if (value > max)
				value = max;
		}
	}
}

void CMenu::KeyBind(int x, int y, int &key)
{
	unsigned int w = 60;
	unsigned int h = 18;

	bool clicked = false;

	static DWORD dwTemporaryBlockTimer = 0;

	if (GetTickCount() - dwPaletteBlockedTime > 200 && GetTickCount() - dwListBlockedTime > 200 && !bCursorInPalette && !bCursorInList && keys[VK_LBUTTON] && !IsDragging && CursorX >= x && CursorX <= x + w && CursorY >= y && CursorY <= y + h)
	{
		if (GetTickCount() - dwTemporaryBlockTimer > 200)
		{
			clicked = true;
			dwTemporaryBlockTimer = GetTickCount();
		}
	}

	if (key == -2 && GetTickCount() - dwTemporaryBlockTimer > 200)
	{
		for (unsigned int i = 0; i < 255; i++)
		{
			if (g_Menu.keys[i])
			{
				if (i == VK_ESCAPE || i == VK_LBUTTON || i == VK_RBUTTON || i == cvar.menu_key) // i == VK_LBUTTON || i == VK_RBUTTON || 
				{
					key = -1;
					break;
				}
				key = i;
			}
		}
	}

	if (clicked)
	{
		if (key == -1) {
			key = -2;
		}
		else {
			key = -1;
		}
	}

	if (key == -1)
	{
		g_Drawing.DrawString(MENU, x + w / 2, y + (h / 2), 255, 0, 0, 255, FONT_CENTER, "[No key]");
	}
	else if (key == -2)
	{
		g_Drawing.DrawString(MENU, x + w / 2, y + (h / 2), 255, 0, 0, 255, FONT_CENTER, "[Press key]");
	}
	else {
		g_Drawing.DrawString(MENU, x + w / 2, y + (h / 2), 255, 0, 0, 255, FONT_CENTER, "[%s]", VirtualKeyCodeToString(key).c_str());
	}
}

void CMenu::Slider(int x, int y, float min, float max, float &value, char *text, bool ThisINT, char *amout, bool extra)
{
	unsigned int w = 200;
	unsigned int h = 12;

	g_pISurface->DrawSetColor(0, 0, 0, 255);//(120,168,93,255);
	g_pISurface->DrawFilledRect(x, y, x + w, y + h);

	g_pISurface->DrawSetColor(255, 0, 0, 255);
	g_pISurface->DrawOutlinedRect(x - 1, y - 1, x + w + 1, y + h + 1);

	g_pISurface->DrawSetColor(0, 0, 0, 255);
	g_pISurface->DrawOutlinedRect(x - 2, y - 2, x + w + 2, y + h + 2);

	if (text)
		g_Drawing.DrawString(MENU, x + 1, y - 10, 0, 0, 0, 255, FONT_LEFT, text);

	if (ThisINT)
		value = (int)value;

	if (value < min)
		value = min;
	else if (value > max)
		value = max;

	float one = (w / max);

	int fill = one * value;

	if (value < 0)
		fill *= -1;

	g_pISurface->DrawSetColor(255, 0, 0, 255);
	g_pISurface->DrawFilledRect(x, y, x + fill, y + h);

	if (!amout)
		amout = "";

	if (!ThisINT)
	{
		if (!extra)
			g_Drawing.DrawString(MENU, x + (w / 2), y + (h / 2), 255, 255, 255, 255, FONT_CENTER, "%.2f%s", value, amout);
		else
			g_Drawing.DrawStringACP(MENU, x + (w / 2), y + (h / 2), 255, 255, 255, 255, FONT_CENTER, "%.2f%s", value, amout);
	}
	else
	{
		if (!extra)
			g_Drawing.DrawString(MENU, x + (w / 2), y + (h / 2), 255, 255, 255, 255, FONT_CENTER, "%.f%s", value, amout);
		else
			g_Drawing.DrawString(MENU, x + (w / 2), y + (h / 2), 255, 255, 255, 255, FONT_CENTER, "%.f%s", value, amout);
	}

	if (GetTickCount() - dwSliderBlockedTime > 200 && GetTickCount() - dwListBlockedTime > 200 && !bCursorInPalette && !bCursorInList && !IsDragging && CursorX >= x && CursorX <= x + w && CursorY >= y && CursorY <= y + h)
	{
		if (keys[VK_LBUTTON]) {
			value = (CursorX - x) / one;

			if (value < min)
				value = min;
			else if (value > max)
				value = max;
		}
		else if (keys[VK_RBUTTON] && min < 0) {
			value = (CursorX - x) / one;
			value *= -1;

			if (value < min)
				value = min;
			else if (value > max)
				value = max;
		}
	}
}

/*void CMenu::DrawMenuTabs()
{
	int tab_x = BORDER_SIZE + 1;
	int tab_y = BORDER_SIZE + 1 + 10;
	int tab_h = ((background.height - (BORDER_SIZE * 2)) / MAX_TABS) - 40;
	int tab_w = tab_x + TAB_WEIGHT;

	int y = BORDER_SIZE + 1 + 15;
	int x = BORDER_SIZE + 1 + 12;

	for (unsigned int i = 1; i <= MAX_TABS; i++)
	{

			g_pISurface->DrawSetColor(120,168,93,255);
			g_pISurface->DrawFilledRect(MenuX + tab_x, MenuY + tab_y, MenuX + tab_w, MenuY + tab_y + tab_h);

			g_pISurface->DrawSetColor(91, 99, 100, 255);
			g_pISurface->DrawFilledRect(MenuX + tab_x, MenuY + tab_y - 1, MenuX + tab_w, MenuY + tab_y);
			g_pISurface->DrawSetColor(0, 0, 0, 255);
			g_pISurface->DrawFilledRect(MenuX + tab_x, MenuY + tab_y - 1, MenuX + tab_w - 1, MenuY + tab_y - 2);

			g_pISurface->DrawSetColor(91, 99, 100, 255);
			g_pISurface->DrawFilledRect(MenuX + tab_x, MenuY + tab_y + tab_h - 1, MenuX + tab_w, MenuY + tab_y + tab_h);
			g_pISurface->DrawSetColor(0, 0, 0, 255);
			g_pISurface->DrawFilledRect(MenuX + tab_x, MenuY + tab_y + tab_h + 1, MenuX + tab_w - 1, MenuY + tab_y + tab_h + 2);


		y = y + tab_h + 20;
		tab_y = tab_y + tab_h + 20;
	}
}*/

void CMenu::Drag()
{
	if (bCursorInList || bCursorInPalette)
	{
		IsDragging = false;
		return;
	}

	static int drag_x = 0;
	static int drag_y = 0;

	if (IsDragging && !keys[VK_LBUTTON])
	{
		IsDragging = false;
	}
	else if (IsDragging && keys[VK_LBUTTON])
	{
		MenuX = CursorX - drag_x;
		MenuY = CursorY - drag_y;
	}

	//head move
	if (keys[VK_LBUTTON] && (
		(CursorX >= MenuX && CursorX <= background.width + MenuX && CursorY >= MenuY && CursorY <= MenuY + BORDER_SIZE) ||
		(CursorX >= MenuX && CursorX <= MenuX + BORDER_SIZE && CursorY >= MenuY && CursorY <= background.height + MenuY) ||
		(CursorX >= MenuX + background.width - BORDER_SIZE && CursorX <= MenuX + background.width && CursorY >= MenuY && CursorY <= background.height + MenuY) ||
		(CursorX >= MenuX && CursorX <= background.width + MenuX && CursorY >= MenuY + background.height - BORDER_SIZE && CursorY <= MenuY + background.height)))
	{
		drag_x = CursorX - MenuX;
		drag_y = CursorY - MenuY;
		IsDragging = true;
	}
}


void CMenu::Checkbox(int x, int y, bool &value, char *text)
{
	static unsigned int w = 10;
	static unsigned int h = 10;

	g_pISurface->DrawSetColor(0, 0, 0, 255);
	g_pISurface->DrawOutlinedRect(x, y, x + w, y + h);

	g_pISurface->DrawSetColor(0, 0, 0, 255);
	g_pISurface->DrawOutlinedRect(x - 1, y - 1, x + w + 1, y + h + 1);

	if (value)
	{
		g_pISurface->DrawSetColor(255, 0, 0, 255);
		g_pISurface->DrawFilledRect(x + 1, y + 1, x + w - 1, y + h - 1);
	}

	if (text)
		g_Drawing.DrawString(MENU, x + 16, y + 4, 5, 5, 20, 255, FONT_LEFT, text);

	if (GetTickCount() - dwCheckboxBlockedTime > 200 && !bCursorInPalette && !bCursorInList && keys[VK_LBUTTON] && !IsDragging && CursorX >= x && CursorX <= x + w && CursorY >= y && CursorY <= y + h)
	{
		value = !value;
		dwCheckboxBlockedTime = GetTickCount();
	}
}

void CMenu::DrawBox(int x, int y, int w, int h)
{
	//box
	g_pISurface->DrawSetColor(255, 255, 255, 255);
	g_pISurface->DrawFilledRect(x, y, x + w, y + h);
	//outline
	g_pISurface->DrawSetColor(0, 0, 0, 255);
	g_pISurface->DrawOutlinedRect(x - 1, y - 1, x + w + 1, y + h + 1);
	//shadow
	//g_pISurface->DrawSetColor(0, 0, 0, 255);
	//g_pISurface->DrawOutlinedRect(x - 2, y - 2, x + w + 2, y + h + 2);
}