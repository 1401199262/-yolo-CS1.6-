#include "json\json.hpp"
#include "Pipi_edit.h"
#include <fstream>
#include <iostream>
#include <time.h>

#define _CRT_SECURE_NO_DEPRECATE
#pragma warning(disable:4996)
using namespace configor;

bool g_mode_auto = 0, g_isScreenCaptureAvaliable = 0;
//json obj = {
//    {
//        "user", {
//            { "id", 10 },
//            { "name", "Nomango" }
//        }
//    }
//};
//
//// �ڶ�������
//json obj2 = 
//{
//    { "nul", nullptr },
//    { "number", 1 },
//    { "float", 1.3 },
//    { "boolean", false },
//    { "string", "���Ĳ���" },
//    { "array", { 1, 2, true, 1.4 } },
//    { "object", {
//        { "key", "value" },
//        { "key2", "value2" },
//    }
//    },
//};

std::ofstream g_jsonfile;
int g_image_count = 0;
HWND g_hwnd = FindWindowA(NULL, "Counter-Strike");
int g_Box_pos[4];
bool writejson(json j) {
	g_jsonfile.open("D:\\CS_CAPTURE\\cs_data.json", std::ios::out | std::ios::in | std::ios::app);
    g_jsonfile << j << "\n";
	g_jsonfile.close();
    return 1;
}



bool __saveBitmap(LPCSTR filename, HBITMAP bmp, HPALETTE pal)
{
	bool result = false;
	PICTDESC pd;

	pd.cbSizeofstruct = sizeof(PICTDESC);
	pd.picType = PICTYPE_BITMAP;
	pd.bmp.hbitmap = bmp;
	pd.bmp.hpal = pal;

	LPPICTURE picture;
	HRESULT res = OleCreatePictureIndirect(&pd, IID_IPicture, false,
		reinterpret_cast<void**>(&picture));

	if (!SUCCEEDED(res))
		return false;

	LPSTREAM stream;
	res = CreateStreamOnHGlobal(0, true, &stream);

	if (!SUCCEEDED(res))
	{
		picture->Release();
		return false;
	}

	LONG bytes_streamed;
	res = picture->SaveAsFile(stream, true, &bytes_streamed);

	HANDLE file = CreateFile(filename, GENERIC_WRITE, FILE_SHARE_READ, 0,
		CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);

	if (!SUCCEEDED(res) || !file)
	{
		stream->Release();
		picture->Release();
		return false;
	}

	HGLOBAL mem = 0;
	GetHGlobalFromStream(stream, &mem);
	LPVOID data = GlobalLock(mem);

	DWORD bytes_written;

	result = !!WriteFile(file, data, bytes_streamed, &bytes_written, 0);
	result &= (bytes_written == static_cast<DWORD>(bytes_streamed));

	GlobalUnlock(mem);
	CloseHandle(file);

	stream->Release();
	picture->Release();

	return result;
}
bool screenCapture(int x, int y, int w, int h, LPCSTR fname) {
	HDC hdcSource = GetDC(NULL);
	HDC hdcMemory = CreateCompatibleDC(hdcSource);

	int capX = GetDeviceCaps(hdcSource, HORZRES);
	int capY = GetDeviceCaps(hdcSource, VERTRES);

	HBITMAP hBitmap = CreateCompatibleBitmap(hdcSource, w, h);
	HBITMAP hBitmapOld = (HBITMAP)SelectObject(hdcMemory, hBitmap);

	BitBlt(hdcMemory, 0, 0, w, h, hdcSource, x, y, SRCCOPY);
	hBitmap = (HBITMAP)SelectObject(hdcMemory, hBitmapOld);

	DeleteDC(hdcSource);
	DeleteDC(hdcMemory);

	HPALETTE hpal = NULL;
	if (__saveBitmap(fname, hBitmap, hpal)) return true;
	return false;
}

void GetCurrentTimerMS(char* szTimer = NULL)
{
	uint64_t nTimer = 0;
	SYSTEMTIME currentTime;
	GetLocalTime(&currentTime);

	tm temptm = { currentTime.wSecond,
		currentTime.wMinute,
		currentTime.wHour,
		currentTime.wDay,
		currentTime.wMonth - 1,
		currentTime.wYear - 1900
	};
	nTimer = mktime(&temptm) * 1000 + currentTime.wMilliseconds;
	
	sprintf(szTimer, "%llu", nTimer);
	return;
}


std::string uint64_to_string(uint64_t value) {
	std::ostringstream os;
	os << value;
	return os.str();
}
void GetAIdata(int data[4]) {
	char szTimer[64];
	GetCurrentTimerMS(szTimer);
	int newdata[4] = { data[0],data[1],data[2],data[3] };
	
	char imagedir[255];
	strncpy(imagedir, "D:/CS_CAPTURE/", sizeof(imagedir));
	strncat(imagedir, szTimer, sizeof(imagedir));
	strncat(imagedir, ".bmp", sizeof(imagedir));
	RECT windowrect;
	::GetWindowRect(g_hwnd, &windowrect);
	screenCapture(windowrect.left + 8, windowrect.top + 31, windowrect.right - windowrect.left - 16,
		windowrect.bottom - windowrect.top - 39, imagedir);//800x600 image size
	

	//BOX����x:%d y:%d BOX����:x:%d y:%d" , int((ScreenTop[0] - (PlayerBoxHeight * 0.25f)) +(PlayerBoxHeight / 2)), int((ScreenTop[1])+(PlayerBoxHeight)), int(ScreenTop[0] - (PlayerBoxHeight * 0.25f)), int(ScreenTop[1]));
	json enemydata = {
		{"name",szTimer + (std::string)".bmp"},
		{"box_pos",{{newdata[0],newdata[1]},{newdata[2],newdata[3]}}}
	};
	writejson(enemydata);	
	printf("��ͼ���=[%s]�ɹ�!\n", szTimer);
}

//void time_thread() {
//	while (1)
//	{
//		Sleep(500);
//		g_isScreenCaptureAvaliable = !g_isScreenCaptureAvaliable;
//	}
//}

void ���ܻ�ȡ������() {
	while (1)
	{//����һ��
		if (g_isScreenCaptureAvaliable==false) {
			Sleep(500);
			g_isScreenCaptureAvaliable = true;
		}
		Sleep(1);
	}

}

DWORD WINAPI hotkey_thread(LPVOID) {
	while (1)
	{
		Sleep(70);
		//if (GetAsyncKeyState(VK_F1) && 0x8000) {
		//	g_mode_manaul = 1;
		//	printf("mode_manaul enabled\n");
		//}
		
		if (GetAsyncKeyState(VK_F2) && 0x8000) {
			g_mode_auto = !g_mode_auto;
			if (g_mode_auto) {
				printf("mode_auto enabled\n");
			}
			else {
				printf("F2 �����Զ��ռ�����\n");
			}
			
		}

	}
}
























//DWORD WINAPI mythread(LPVOID) {
//	Sleep(5000);
//	printf("[SYS] threadcreated\n");
//	//manual capture
//	if (GetAsyncKeyState(VK_F1) && 0x8000) {
//		//GetAIdata();
//		printf("[count=%d] manaul gets data ok\n", g_image_count);
//
//		//��ֹ�����ͼ
//		Sleep(50);
//		
//	}
//
//	//auto capture
//	if (GetAsyncKeyState(VK_F2) && 0x8000) {
//		while (1)
//		{
//			printf("[count=%d] auto gets data ok\n", g_image_count);
//			//GetAIdata();
//			if (GetAsyncKeyState(VK_F2)) { break; }
//			Sleep(500);
//		}
//	}
//
//
//}