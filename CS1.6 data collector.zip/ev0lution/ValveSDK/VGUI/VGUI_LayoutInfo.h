//========= Copyright � 1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

#ifndef VGUI_LAYOUTINFO_H
#define VGUI_LAYOUTINFO_H

namespace vgui
{

class VGUIAPI LayoutInfo
{
	virtual LayoutInfo* getThis()=0;
};

}

#endif