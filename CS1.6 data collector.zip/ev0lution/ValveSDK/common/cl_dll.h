typedef unsigned char byte;
typedef unsigned short word;
typedef float vec_t;
typedef int(*pfnUserMsgHook)(const char *pszName, int iSize, void *pbuf);