
import jsonlines
import cv2
import glob
import os
import numpy as np
import codecs
import json
import glob
import cv2
import shutil
from sklearn.model_selection import train_test_split

json_dir = r"D:\CS_CAPTURE\cs_data.json"  # json文件路径
out_dir = r"D:\CS_CAPTURE\labels"  # 输出的文件路径

with open(json_dir, "r+", encoding="utf8") as f:
    for item in jsonlines.Reader(f):
        filename=item['name'][0:13]
        #line = json.dumps(item)
        topx=item["box_pos"][0][0]
        topy=item["box_pos"][0][1]
        botx=item["box_pos"][1][0]
        boty=item["box_pos"][1][1]
        w=abs(botx-topx)/800
        h=abs(boty-topy)/600
        x=(botx+topx)/2/800
        y=(topx+topy)/2/600
        txtfile = open(out_dir+'\\'+filename+'.txt', 'w')
        print("正在处理:"+filename+'.txt')
        txtfile.write('0 '+str(format(x, '.6f'))+' '+str(format(y, '.6f'))+' '+str(format(w, '.6f'))+' '+str(format(h, '.6f')))
        txtfile.close()
f.close()

# jsonlists = os.listdir(out_dir+"\\json\\")
# for i,jsonfilename in enumerate(jsonlists):
#     jsonfile=open(out_dir+"\\json\\"+jsonfilename)
#     jsonline=jsonfile.readline()
#     line=json.loads(jsonline)
#     topx=line["box_pos"][0][0]
#     topy=line["box_pos"][0][1]
#     botx=line["box_pos"][1][0]
#     boty=line["box_pos"][1][1]
#     w=botx-topx
#     h=boty-topy
#     x=(botx+topx)/2
#     y=(topx+topy)/2
#     txtfile=open(out_dir+"\\txt\\"+jsonfilename,'w')





exit()
# 读取 json 文件数据
with open(json_dir, 'r') as load_f:
    content = json.load(load_f)

# 循环处理
for t in content:
    tmp = t['name'].split('.')
    filename = out_dir + tmp[0] + '.txt'

    if os.path.exists(filename):
        # 计算 yolo 数据格式所需要的中心点的 相对 x, y 坐标, w,h 的值
        x = (t['bbox'][0] + t['bbox'][2]) / 2 / t['image_width']
        y = (t['bbox'][1] + t['bbox'][3]) / 2 / t['image_height']
        w = (t['bbox'][2] - t['bbox'][0]) / t['image_width']
        h = (t['bbox'][3] - t['bbox'][1]) / t['image_height']
        fp = open(filename, mode="r+", encoding="utf-8")
        file_str = str(t['category']) + ' ' + str(round(x, 6)) + ' ' + str(round(y, 6)) + ' ' + str(round(w, 6)) + \
                   ' ' + str(round(h, 6))
        line_data = fp.readlines()
        if len(line_data) != 0:
            fp.write('\n' + file_str)
        else:
            fp.write(file_str)
        fp.close()

        # 不存在则创建文件
    else:
        fp = open(filename, mode="w", encoding="utf-8")
        fp.close()

