import os
import cv2

# 图片的路径
bmp_dir = r"D:\CS_CAPTURE"
jpg_dir = r"D:\CS_CAPTURE\labels"

filelists = os.listdir(bmp_dir)

for i,file in enumerate(filelists):
    # 读图，-1为不改变图片格式，0为灰度图  
    if (file[-4:]==".bmp"):
        img = cv2.imread(os.path.join(bmp_dir,file),-1)
        newName = file.replace('.bmp','.jpg')
        cv2.imwrite(os.path.join(jpg_dir,newName),img)
        print('第%d张图：%s'%(i+1,newName))
    else:
        print("文件:"+file+"不可转换")
